using System.Windows.Controls;

namespace HamerApp.Views.Public
{
    public partial class VacanciesView : UserControl
    {
        public VacanciesView()
        {
            InitializeComponent();
        }
    }
}