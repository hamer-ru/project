using System.Windows.Controls;

namespace HamerApp.Views.Public
{
    public partial class PricesView : UserControl
    {
        public PricesView()
        {
            InitializeComponent();
        }
    }
}