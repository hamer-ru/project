using System.Windows.Controls;

namespace HamerApp.Views.Public
{
    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}