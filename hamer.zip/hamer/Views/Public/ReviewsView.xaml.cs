using System.Windows.Controls;

namespace HamerApp.Views.Public
{
    public partial class ReviewsView : UserControl
    {
        public ReviewsView()
        {
            InitializeComponent();
        }
    }
}