using System.Windows.Controls;

namespace HamerApp.Views.Public
{
    public partial class ContactsView : UserControl
    {
        public ContactsView()
        {
            InitializeComponent();
        }
    }
}