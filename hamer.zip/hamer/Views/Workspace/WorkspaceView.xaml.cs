using System.Windows.Controls;

namespace HamerApp.Views.Workspace
{
    public partial class WorkspaceView : UserControl
    {
        public WorkspaceView()
        {
            InitializeComponent();
        }
    }
}