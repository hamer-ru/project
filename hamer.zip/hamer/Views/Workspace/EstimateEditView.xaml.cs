using System.Windows.Controls;

namespace HamerApp.Views.Workspace
{
    public partial class EstimateEditView : UserControl
    {
        public EstimateEditView()
        {
            InitializeComponent();
        }
    }
}