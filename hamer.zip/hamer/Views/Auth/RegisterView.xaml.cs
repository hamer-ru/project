using System.Windows.Controls;

namespace HamerApp.Views.Auth
{
    public partial class RegisterView : UserControl
    {
        public RegisterView()
        {
            InitializeComponent();
        }
    }
}