using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public class Brigade
{
    [Key] public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Members { get; set; } = string.Empty;
    public bool IsBusy { get; set; }
}