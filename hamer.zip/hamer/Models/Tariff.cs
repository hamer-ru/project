using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public class Tariff
{
    [Key] public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Price { get; set; } = string.Empty;
    public string Works { get; set; } = string.Empty;
}