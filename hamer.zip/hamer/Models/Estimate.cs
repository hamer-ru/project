using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace HamerApp.Models;

public class Estimate
{
    [Key] public int Id { get; set; }
    public string Number { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public int PropertyId { get; set; }
    public Property? Property { get; set; }
    public ICollection<EstimateItem> Items { get; set; } = new List<EstimateItem>();
    
    [NotMapped] public decimal Total => Items?.Sum(i => i.TotalPrice) ?? 0;
}