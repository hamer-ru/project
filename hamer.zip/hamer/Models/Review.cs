using System;
using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public class Review
{
    [Key] public int Id { get; set; }
    public string ServiceType { get; set; } = string.Empty;
    public string Text { get; set; } = string.Empty;
    public int Rating { get; set; }
    public DateTime Date { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Initials { get; set; } = string.Empty;
}