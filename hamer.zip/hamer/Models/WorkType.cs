using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public class WorkType
{
    [Key] public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = string.Empty;
    public decimal BasePrice { get; set; }
}