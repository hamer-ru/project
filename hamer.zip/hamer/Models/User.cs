using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public enum UserRole { Director, Estimator, Foreman, Client }

public class User
{
    [Key] public int Id { get; set; }
    [Required] public string Email { get; set; } = string.Empty;
    [Required] public string Password { get; set; } = string.Empty;
    public UserRole Role { get; set; }
    public string? FullName { get; set; }
}