using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public class Material
{
    [Key] public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public double Stock { get; set; }
    public decimal Price { get; set; }
}