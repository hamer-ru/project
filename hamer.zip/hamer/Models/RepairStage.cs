using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HamerApp.Models;

public enum StageStatus { Planned, InProgress, Completed, Overdue }

public class RepairStage
{
    [Key] public int Id { get; set; }
    public int PropertyId { get; set; }
    public Property? Property { get; set; }
    public int? BrigadeId { get; set; }
    public Brigade? Brigade { get; set; }
    public DateTime PlanStart { get; set; }
    public DateTime PlanEnd { get; set; }
    public DateTime? FactEnd { get; set; }
    public StageStatus Status { get; set; }
    
    [NotMapped] public bool IsOverdue => Status != StageStatus.Completed && PlanEnd < DateTime.Now;
}