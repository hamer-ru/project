using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public enum PropertyStatus { Planning, InProgress, Completed }

public class Property
{
    [Key] public int Id { get; set; }
    public string Address { get; set; } = string.Empty;
    public double Area { get; set; }
    public PropertyStatus Status { get; set; }
    public int ClientId { get; set; }
    public Client? Client { get; set; }
    public ICollection<RepairStage> Stages { get; set; } = new List<RepairStage>();
    public ICollection<Estimate> Estimates { get; set; } = new List<Estimate>();
}