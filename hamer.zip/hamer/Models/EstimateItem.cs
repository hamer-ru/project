using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HamerApp.Models;

public class EstimateItem
{
    [Key] public int Id { get; set; }
    public int EstimateId { get; set; }
    public Estimate? Estimate { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    [NotMapped] public decimal TotalPrice => Quantity * UnitPrice;
}