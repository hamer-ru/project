using System;
using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public class ExtraWork
{
    [Key] public int Id { get; set; }
    public int PropertyId { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Cost { get; set; }
    public bool IsApproved { get; set; }
    public DateTime WarrantyDate { get; set; }
}