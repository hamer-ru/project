using System;
using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public enum PaymentType { Advance, Progress, Final }

public class Payment
{
    [Key] public int Id { get; set; }
    public int PropertyId { get; set; }
    public decimal Amount { get; set; }
    public DateTime Date { get; set; }
    public PaymentType Type { get; set; }
}