using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HamerApp.Models;

public class Client
{
    [Key] public int Id { get; set; }
    [Required] public string Name { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string? Email { get; set; }
    public ICollection<Property> Properties { get; set; } = new List<Property>();
}