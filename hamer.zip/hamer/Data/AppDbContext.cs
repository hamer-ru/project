using System;
using HamerApp.Models;
using Microsoft.EntityFrameworkCore;

namespace HamerApp.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Client> Clients => Set<Client>();
    public DbSet<Property> Properties => Set<Property>();
    public DbSet<WorkType> WorkTypes => Set<WorkType>();
    public DbSet<Estimate> Estimates => Set<Estimate>();
    public DbSet<EstimateItem> EstimateItems => Set<EstimateItem>();
    public DbSet<Material> Materials => Set<Material>();
    public DbSet<Brigade> Brigades => Set<Brigade>();
    public DbSet<RepairStage> RepairStages => Set<RepairStage>();
    public DbSet<ExtraWork> ExtraWorks => Set<ExtraWork>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<Review> Reviews => Set<Review>();
    public DbSet<Vacancy> Vacancies => Set<Vacancy>();
    public DbSet<Tariff> Tariffs => Set<Tariff>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>().HasData(
            new User { Id = 1, Email = "director@hamer.ru", Password = "123", Role = UserRole.Director, FullName = "Иванов И.И." },
            new User { Id = 2, Email = "estimator@hamer.ru", Password = "123", Role = UserRole.Estimator, FullName = "Петров П.П." },
            new User { Id = 3, Email = "foreman@hamer.ru", Password = "123", Role = UserRole.Foreman, FullName = "Сидоров С.С." }
        );

        modelBuilder.Entity<Tariff>().HasData(
            new Tariff { Id = 1, Title = "Косметический", Price = "от 6 500 ₽/м²", Works = "Демонтаж старых покрытий\nШтукатурка и шпаклёвка\nПоклейка обоев, покраска\nУкладка ламината\nЗамена плинтусов" },
            new Tariff { Id = 2, Title = "Капитальный", Price = "от 12 000 ₽/м²", Works = "Демонтаж до бетона\nЭлектрика и сантехника\nВыравнивание стен и полов\nЧистовая отделка\nМонтаж дверей" },
            new Tariff { Id = 3, Title = "Дизайнерский", Price = "от 20 000 ₽/м²", Works = "Авторский надзор\nЭксклюзивные материалы\nСложные потолки\nСкрытый монтаж\nДекоративные элементы" }
        );

        modelBuilder.Entity<Vacancy>().HasData(
            new Vacancy { Id = 1, Title = "Мастер-отделочник", Description = "Опыт от 3 лет, знание современных технологий, аккуратность и ответственность.", Salary = "от 80 000 ₽" },
            new Vacancy { Id = 2, Title = "Прораб", Description = "Управление объектами, контроль сроков и качества, взаимодействие с заказчиками.", Salary = "от 120 000 ₽" },
            new Vacancy { Id = 3, Title = "Дизайнер интерьеров", Description = "Разработка дизайн-проектов, авторский надзор, работа с клиентами.", Salary = "от 90 000 ₽" }
        );

        modelBuilder.Entity<Brigade>().HasData(
            new Brigade { Id = 1, Name = "Бригада №1 (Универсалы)", Members = "Иванов, Петров, Сидоров", IsBusy = true },
            new Brigade { Id = 2, Name = "Бригада №2 (Отделочники)", Members = "Смирнов, Кузнецов", IsBusy = false }
        );

        modelBuilder.Entity<Client>().HasData(
            new Client { Id = 1, Name = "ООО Ромашка", Phone = "+7 (999) 111-22-33" }
        );

        modelBuilder.Entity<Property>().HasData(
            new Property { Id = 1, Address = "г. Москва, ул. Ленина, д. 1", Area = 55.5, Status = PropertyStatus.InProgress, ClientId = 1 }
        );
    }
}