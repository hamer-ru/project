﻿using System;
using System.Windows;
using System.Windows.Threading;
using HamerApp.Data;
using HamerApp.Services;
using HamerApp.ViewModels;
using HamerApp.Views;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace HamerApp;

public partial class App : Application
{
    public static IServiceProvider ServiceProvider { get; private set; } = null!;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException += App_DispatcherUnhandledException;

        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        var services = new ServiceCollection();
        services.AddSingleton<IConfiguration>(configuration);
        services.AddDbContext<AppDbContext>(options => 
            options.UseSqlite(configuration.GetConnectionString("DefaultConnection")));
        
        services.AddSingleton<ExcelExportService>();
        services.AddSingleton<DialogService>();
        services.AddTransient<AuthViewModel>();
        services.AddTransient<PublicPagesViewModel>();
        services.AddTransient<WorkspaceViewModel>();
        services.AddSingleton<MainViewModel>();
        services.AddSingleton<MainWindow>();

        ServiceProvider = services.BuildServiceProvider();

        using (var scope = ServiceProvider.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            db.Database.EnsureCreated();
        }

        var mainWindow = ServiceProvider.GetRequiredService<MainWindow>();
        mainWindow.DataContext = ServiceProvider.GetRequiredService<MainViewModel>();
        mainWindow.Show();
    }

    public static void SwitchTheme(bool isDark)
    {
        try
        {
            var dict = new ResourceDictionary
            {
                Source = new Uri(isDark ? "Styles/DarkTheme.xaml" : "Styles/Theme.xaml", UriKind.Relative)
            };
            Current.Resources.MergedDictionaries.Clear();
            Current.Resources.MergedDictionaries.Add(dict);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка смены темы: {ex.Message}", "HAMER", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        MessageBox.Show($"Ошибка: {e.Exception.Message}", "HAMER", MessageBoxButton.OK, MessageBoxImage.Error);
        e.Handled = true;
    }
}