namespace HamerApp.Services;

public class DialogService
{
}