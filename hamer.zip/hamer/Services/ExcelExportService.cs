using System.Collections;
using System.Linq;
using ClosedXML.Excel;

namespace HamerApp.Services;

public class ExcelExportService
{
    public void Export(IEnumerable data, string fileName, string sheetName)
    {
        using var workbook = new XLWorkbook();
        var worksheet = workbook.Worksheets.Add(sheetName);
        var items = data.Cast<object>().ToList();
        
        if (items.Count == 0) return;

        var properties = items[0].GetType().GetProperties();
        for (int i = 0; i < properties.Length; i++)
        {
            worksheet.Cell(1, i + 1).Value = properties[i].Name;
            worksheet.Cell(1, i + 1).Style.Font.Bold = true;
        }

        for (int r = 0; r < items.Count; r++)
        {
            for (int c = 0; c < properties.Length; c++)
            {
                var value = properties[c].GetValue(items[r]);
                worksheet.Cell(r + 2, c + 1).Value = value?.ToString() ?? string.Empty;
            }
        }

        worksheet.Columns().AdjustToContents();
        workbook.SaveAs(fileName);
    }
}