using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using HamerApp.Models;

namespace HamerApp.ViewModels;

public partial class PublicPagesViewModel : ObservableObject
{
    [ObservableProperty] private ObservableCollection<Review> _reviews = new();
    [ObservableProperty] private ObservableCollection<Tariff> _tariffs = new();
    [ObservableProperty] private ObservableCollection<Vacancy> _vacancies = new();
    
    [ObservableProperty] private string _newReviewName = string.Empty;
    [ObservableProperty] private string _newReviewText = string.Empty;
    [ObservableProperty] private Tariff? _selectedTariffForReview;
    [ObservableProperty] private int _newReviewRating = 5;

    partial void OnNewReviewNameChanged(string value)
    {
        if (string.IsNullOrEmpty(value)) return;
        var filtered = new string(value.Where(c => 
            (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || 
            (c >= 'а' && c <= 'я') || (c >= 'А' && c <= 'Я') || 
            c == 'ё' || c == 'Ё'
        ).ToArray());

        if (filtered.Length > 30) filtered = filtered.Substring(0, 30);

        if (_newReviewName != filtered)
        {
            NewReviewName = filtered;
        }
    }

    public int MaxReviewLength => 180;
    public int ReviewTextLength => NewReviewText?.Length ?? 0;

    partial void OnNewReviewTextChanged(string value)
    {
        if (value != null && value.Length > MaxReviewLength)
        {
            NewReviewText = value.Substring(0, MaxReviewLength);
        }
        OnPropertyChanged(nameof(ReviewTextLength));
    }

    [ObservableProperty] private string _clientName = string.Empty;
    partial void OnClientNameChanged(string value)
    {
        var filtered = new string((value ?? "").Where(c => 
            (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || 
            (c >= 'а' && c <= 'я') || (c >= 'А' && c <= 'Я') || 
            c == 'ё' || c == 'Ё' || c == ' '
        ).ToArray());
        
        if (filtered.Length > 50) filtered = filtered.Substring(0, 50);

        if (_clientName != filtered)
        {
            ClientName = filtered;
        }
    }

    private string _clientPhone = "+7 ";
    public string ClientPhone
    {
        get => _clientPhone;
        set
        {
            var digits = new string((value ?? "").Where(char.IsDigit).ToArray());
            if (digits.StartsWith("7")) digits = digits.Substring(1);
            if (digits.Length > 10) digits = digits.Substring(0, 10);
            
            var fmt = "+7";
            if (digits.Length > 0) fmt += " (" + digits.Substring(0, Math.Min(3, digits.Length));
            if (digits.Length >= 3) fmt += ") ";
            if (digits.Length > 3) fmt += digits.Substring(3, Math.Min(3, digits.Length - 3));
            if (digits.Length >= 6) fmt += "-";
            if (digits.Length > 6) fmt += digits.Substring(6, Math.Min(2, digits.Length - 6));
            if (digits.Length >= 8) fmt += "-";
            if (digits.Length > 8) fmt += digits.Substring(8, Math.Min(2, digits.Length - 8));

            if (_clientPhone != fmt)
            {
                _clientPhone = fmt;
                OnPropertyChanged();
            }
        }
    }

    public event Action? NavigateToPricesRequested;
    public event Action? NavigateToContactsRequested;

    private readonly string _dataDir = AppDomain.CurrentDomain.BaseDirectory;

    public PublicPagesViewModel()
    {
        LoadDataFromJson();
    }

    private void LoadDataFromJson()
    {
        try
        {
            // Услуги из xlsx
            string tariffsFile = Path.Combine(_dataDir, "services.json");
            if (File.Exists(tariffsFile))
            {
                var json = File.ReadAllText(tariffsFile);
                Tariffs = JsonSerializer.Deserialize<ObservableCollection<Tariff>>(json) ?? GetDefaultTariffs();
            }
            else
            {
                Tariffs = GetDefaultTariffs();
                File.WriteAllText(tariffsFile, JsonSerializer.Serialize(Tariffs));
            }

            // Вакансии из xlsx
            string vacanciesFile = Path.Combine(_dataDir, "vacancies.json");
            if (File.Exists(vacanciesFile))
            {
                var json = File.ReadAllText(vacanciesFile);
                Vacancies = JsonSerializer.Deserialize<ObservableCollection<Vacancy>>(json) ?? GetDefaultVacancies();
            }
            else
            {
                Vacancies = GetDefaultVacancies();
                File.WriteAllText(vacanciesFile, JsonSerializer.Serialize(Vacancies));
            }

            // Отзывы
            string reviewsFile = Path.Combine(_dataDir, "reviews.json");
            if (File.Exists(reviewsFile))
            {
                var json = File.ReadAllText(reviewsFile);
                Reviews = JsonSerializer.Deserialize<ObservableCollection<Review>>(json) ?? GetDefaultReviews();
            }
            else
            {
                Reviews = GetDefaultReviews();
                SaveReviewsToJson();
            }
        }
        catch
        {
            Tariffs = GetDefaultTariffs();
            Vacancies = GetDefaultVacancies();
            Reviews = GetDefaultReviews();
        }
    }

    private void SaveReviewsToJson()
    {
        try
        {
            string reviewsFile = Path.Combine(_dataDir, "reviews.json");
            File.WriteAllText(reviewsFile, JsonSerializer.Serialize(Reviews));
        }
        catch { }
    }

    private ObservableCollection<Tariff> GetDefaultTariffs() => new()
    {
        new Tariff { Id = 1, Title = "Уборка квартиры", Price = "5000.00 ₽ / кв.м", Works = "Генеральная уборка жилых помещений" },
        new Tariff { Id = 2, Title = "Ремонт крана", Price = "1500.00 ₽ / шт", Works = "Замена смесителя или ремонт протечки" },
        new Tariff { Id = 3, Title = "Установка розетки", Price = "800.00 ₽ / шт", Works = "Монтаж и подключение электрической розетки" },
        new Tariff { Id = 4, Title = "Покраска стен", Price = "650.00 ₽ / кв.м", Works = "Подготовка и покраска стен водоэмульсионной краской" },
        new Tariff { Id = 5, Title = "Укладка ламината", Price = "900.00 ₽ / кв.м", Works = "Монтаж подложки и укладка ламината" },
        new Tariff { Id = 6, Title = "Установка люстры", Price = "2200.00 ₽ / шт", Works = "Сборка и подключение потолочного светильника" },
        new Tariff { Id = 7, Title = "Замена унитаза", Price = "3500.00 ₽ / шт", Works = "Демонтаж старого и установка нового унитаза" },
        new Tariff { Id = 8, Title = "Поклейка обоев", Price = "550.00 ₽ / кв.м", Works = "Снятие старых обоев и поклейка новых" },
        new Tariff { Id = 9, Title = "Установка двери", Price = "4500.00 ₽ / шт", Works = "Монтаж межкомнатной двери с фурнитурой" },
        new Tariff { Id = 10, Title = "Чистка кондиционера", Price = "3000.00 ₽ / шт", Works = "Антибактериальная чистка и дозаправка фреоном" },
        new Tariff { Id = 11, Title = "Мойка окон", Price = "700.00 ₽ / шт", Works = "Двусторонняя мойка окон и рам" },
        new Tariff { Id = 12, Title = "Замена проводки", Price = "1200.00 ₽ / п.м", Works = "Прокладка нового медного кабеля в штробе" },
        new Tariff { Id = 13, Title = "Сборка мебели", Price = "2500.00 ₽ / шт", Works = "Сборка шкафа или кухонного гарнитура" },
        new Tariff { Id = 14, Title = "Установка счетчика воды", Price = "1800.00 ₽ / шт", Works = "Монтаж и опломбировка водосчетчика" },
        new Tariff { Id = 15, Title = "Штукатурка стен", Price = "850.00 ₽ / кв.м", Works = "Выравнивание стен по маякам" }
    };

    private ObservableCollection<Vacancy> GetDefaultVacancies() => new()
    {
        new Vacancy { Id = 1, Title = "Уборщик", Salary = "40000.00 ₽", Description = "Требуется уборщик с опытом работы" },
        new Vacancy { Id = 2, Title = "Сантехник", Salary = "60000.00 ₽", Description = "Требуется сантехник на постоянную работу" },
        new Vacancy { Id = 3, Title = "Электрик", Salary = "15000.00 ₽", Description = "Разовая подработка" },
        new Vacancy { Id = 4, Title = "Маляр-штукатур", Salary = "65000.00 ₽", Description = "Отделка квартир и офисов под ключ" },
        new Vacancy { Id = 5, Title = "Плотник", Salary = "58000.00 ₽", Description = "Установка межкомнатных дверей и сборка мебели" },
        new Vacancy { Id = 6, Title = "Мастер по кондиционерам", Salary = "70000.00 ₽", Description = "Обслуживание и монтаж сплит-систем" },
        new Vacancy { Id = 7, Title = "Менеджер по работе с клиентами", Salary = "50000.00 ₽", Description = "Прием заявок и консультирование по услугам" },
        new Vacancy { Id = 8, Title = "Плиточник", Salary = "75000.00 ₽", Description = "Укладка керамической плитки и керамогранита" },
        new Vacancy { Id = 9, Title = "Разнорабочий", Salary = "38000.00 ₽", Description = "Помощь мастерам на объектах, погрузка материалов" },
        new Vacancy { Id = 10, Title = "Сметчик", Salary = "80000.00 ₽", Description = "Расчет стоимости ремонтных работ на объекте" },
        new Vacancy { Id = 11, Title = "Мойщик окон", Salary = "45000.00 ₽", Description = "Сезонная мойка окон и фасадов" },
        new Vacancy { Id = 12, Title = "Бригадир", Salary = "90000.00 ₽", Description = "Контроль качества и сроков выполнения ремонтов" },
        new Vacancy { Id = 13, Title = "Водитель-экспедитор", Salary = "55000.00 ₽", Description = "Доставка строительных материалов на объекты" },
        new Vacancy { Id = 14, Title = "Мастер на час", Salary = "52000.00 ₽", Description = "Мелкий бытовой ремонт у клиентов на дому" },
        new Vacancy { Id = 15, Title = "Инженер ОВиК", Salary = "85000.00 ₽", Description = "Проектирование и монтаж систем вентиляции" }
    };

    private ObservableCollection<Review> GetDefaultReviews() => new()
    {
        new Review { Id = 1, ServiceType = "Уборка квартиры", Text = "Отличная уборка, все блестит!", Rating = 5, Date = DateTime.Now, Name = "Мария", Initials = "М" }
    };

    [RelayCommand] private void GoToPrices() => NavigateToPricesRequested?.Invoke();
    [RelayCommand] private void GoToContacts() => NavigateToContactsRequested?.Invoke();

    [RelayCommand]
    private async Task SendRequest()
    {
        if (string.IsNullOrWhiteSpace(ClientName) || ClientPhone.Length < 18)
        {
            System.Windows.MessageBox.Show("Заполните имя и корректный номер телефона полностью.", "HAMER", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
            return;
        }
        System.Windows.MessageBox.Show("Заявка успешно отправлена! Мы свяжемся с вами в течение 15 минут.", "HAMER", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
        ClientName = string.Empty;
        ClientPhone = "+7 ";
        await Task.CompletedTask;
    }

    [RelayCommand]
    private void AddReview()
    {
        if (string.IsNullOrWhiteSpace(NewReviewName) || string.IsNullOrWhiteSpace(NewReviewText)) return;
        
        var review = new Review
        {
            Name = NewReviewName,
            Initials = NewReviewName.Length >= 1 ? NewReviewName.Substring(0, 1).ToUpper() : "А",
            Text = NewReviewText,
            ServiceType = SelectedTariffForReview?.Title ?? "Общая услуга",
            Date = DateTime.Now,
            Rating = NewReviewRating
        };
        
        Reviews.Insert(0, review);
        SaveReviewsToJson();
        
        NewReviewName = string.Empty;
        NewReviewText = string.Empty;
        OnPropertyChanged(nameof(ReviewTextLength));
    }
}