using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using HamerApp.Models;
using HamerApp.Services;
using Microsoft.Extensions.DependencyInjection;

namespace HamerApp.ViewModels;

public partial class WorkspaceViewModel : ObservableObject
{
    [ObservableProperty] private User? _currentUser;
    [ObservableProperty] private ObservableCollection<Client> _clients = new();
    [ObservableProperty] private ObservableCollection<Property> _properties = new();
    [ObservableProperty] private ObservableCollection<WorkType> _workTypes = new();
    [ObservableProperty] private ObservableCollection<Estimate> _estimates = new();
    [ObservableProperty] private ObservableCollection<Material> _materials = new();
    [ObservableProperty] private ObservableCollection<Brigade> _brigades = new();
    [ObservableProperty] private ObservableCollection<RepairStage> _repairStages = new();
    [ObservableProperty] private ObservableCollection<ExtraWork> _extraWorks = new();
    [ObservableProperty] private ObservableCollection<Payment> _payments = new();
    [ObservableProperty] private object? _selectedItem;
    [ObservableProperty] private string _searchText = string.Empty;
    [ObservableProperty] private string _activeTab = "Clients";

    private readonly ExcelExportService _excelService;

    public WorkspaceViewModel()
    {
        _excelService = App.ServiceProvider.GetRequiredService<ExcelExportService>();
        LoadFullData();
    }

    partial void OnCurrentUserChanged(User? value)
    {
        LoadFullData();
    }

    private void LoadFullData()
    {
        var allClients = new List<Client>
        {
            new() { Id = 1, Name = "Соколов Артём Владимирович", Phone = "+7 (926) 194-05-83", Email = "socolart@mail.ru" },
            new() { Id = 2, Name = "Морозова Екатерина Дмитриевна", Phone = "+7 (985) 309-47-16", Email = "kety17m@yandex.ru" },
            new() { Id = 3, Name = "Смирнова Анна Сергеевна", Phone = "+7 (916) 452-83-91", Email = "anna.smirnova@mail.ru" },
            new() { Id = 4, Name = "Волков Дмитрий Андреевич", Phone = "+7 (903) 784-92-01", Email = "d.volkov@gmail.com" },
            new() { Id = 5, Name = "Кузнецова Ольга Игоревна", Phone = "+7 (925) 610-38-47", Email = "olga_kuz@yandex.ru" },
            new() { Id = 6, Name = "Попов Сергей Николаевич", Phone = "+7 (915) 928-37-46", Email = "spopov88@bk.ru" },
            new() { Id = 7, Name = "Васильева Елена Павловна", Phone = "+7 (963) 102-93-84", Email = "elena.vas@mail.ru" },
            new() { Id = 8, Name = "Лебедев Максим Олегович", Phone = "+7 (905) 384-75-62", Email = "m.lebedev@gmail.com" },
            new() { Id = 9, Name = "Новикова Татьяна Викторовна", Phone = "+7 (910) 495-86-73", Email = "t.novikova@yandex.ru" },
            new() { Id = 10, Name = "Козлов Алексей Михайлович", Phone = "+7 (977) 506-97-84", Email = "alex.kozlov@mail.ru" },
            new() { Id = 11, Name = "Федорова Наталья Александровна", Phone = "+7 (999) 617-08-95", Email = "n.fedorova@inbox.ru" },
            new() { Id = 12, Name = "Михайлов Роман Юрьевич", Phone = "+7 (916) 728-19-06", Email = "r.mikhailov@gmail.com" },
            new() { Id = 13, Name = "Белова Мария Константиновна", Phone = "+7 (926) 839-20-17", Email = "m.belova@yandex.ru" },
            new() { Id = 14, Name = "Тарасов Илья Денисович", Phone = "+7 (903) 940-31-28", Email = "i.tarasov@mail.ru" },
            new() { Id = 15, Name = "Громова Светлана Евгеньевна", Phone = "+7 (985) 051-42-39", Email = "s.gromova@yandex.ru" }
        };

        var allProperties = new List<Property>
        {
            new() { Id = 1, Address = "г. Москва, ул. Ленина, д. 1", Area = 65.0, Status = PropertyStatus.Completed, ClientId = 1, Client = allClients[0] },
            new() { Id = 2, Address = "г. Москва, ул. Тверская, д. 18", Area = 82.5, Status = PropertyStatus.InProgress, ClientId = 2, Client = allClients[1] },
            new() { Id = 3, Address = "г. Москва, пр-т Мира, д. 45, кв. 12", Area = 54.0, Status = PropertyStatus.Completed, ClientId = 3, Client = allClients[2] },
            new() { Id = 4, Address = "г. Москва, ул. Арбат, д. 12, кв. 5", Area = 110.0, Status = PropertyStatus.Completed, ClientId = 4, Client = allClients[3] },
            new() { Id = 5, Address = "г. Москва, Ленинский пр-т, д. 72, кв. 88", Area = 74.2, Status = PropertyStatus.InProgress, ClientId = 5, Client = allClients[4] },
            new() { Id = 6, Address = "г. Москва, ул. Профсоюзная, д. 33, кв. 19", Area = 48.0, Status = PropertyStatus.InProgress, ClientId = 6, Client = allClients[5] },
            new() { Id = 7, Address = "г. Москва, Кутузовский пр-т, д. 24, кв. 41", Area = 95.0, Status = PropertyStatus.Completed, ClientId = 7, Client = allClients[6] },
            new() { Id = 8, Address = "г. Москва, ул. Вавилова, д. 19, кв. 7", Area = 61.5, Status = PropertyStatus.Planning, ClientId = 8, Client = allClients[7] },
            new() { Id = 9, Address = "г. Москва, Дмитровское ш., д. 89, кв. 104", Area = 42.0, Status = PropertyStatus.Completed, ClientId = 9, Client = allClients[8] },
            new() { Id = 10, Address = "г. Москва, Варшавское ш., д. 56, кв. 32", Area = 68.0, Status = PropertyStatus.InProgress, ClientId = 10, Client = allClients[9] },
            new() { Id = 11, Address = "г. Москва, ул. Люблинская, д. 112, кв. 64", Area = 53.0, Status = PropertyStatus.Planning, ClientId = 11, Client = allClients[10] },
            new() { Id = 12, Address = "г. Москва, ул. Покровка, д. 28, кв. 3", Area = 88.0, Status = PropertyStatus.Completed, ClientId = 12, Client = allClients[11] },
            new() { Id = 13, Address = "г. Москва, Садовое кольцо, д. 10, кв. 15", Area = 120.0, Status = PropertyStatus.InProgress, ClientId = 13, Client = allClients[12] },
            new() { Id = 14, Address = "г. Москва, ул. Строителей, д. 5, кв. 29", Area = 57.5, Status = PropertyStatus.Completed, ClientId = 14, Client = allClients[13] },
            new() { Id = 15, Address = "г. Москва, Рублевское ш., д. 40, кв. 9", Area = 145.0, Status = PropertyStatus.Planning, ClientId = 15, Client = allClients[14] }
        };

        var allBrigades = new List<Brigade>
        {
            new() { Id = 1, Name = "Сантехник (+7 916 482-91-04)", Members = "Мастер-сантехник (ID: 4)", IsBusy = true },
            new() { Id = 2, Name = "Электрик (+7 903 751-83-92)", Members = "Мастер-электрик (ID: 5)", IsBusy = false },
            new() { Id = 3, Name = "Специалист по клинингу (+7 926 111-22-33)", Members = "Клининг-специалист (ID: 11)", IsBusy = true },
            new() { Id = 4, Name = "Маляр-штукатур (+7 915 222-33-44)", Members = "Отделочник (ID: 12)", IsBusy = false },
            new() { Id = 5, Name = "Плотник (+7 905 333-44-55)", Members = "Плотник-сборщик (ID: 13)", IsBusy = true },
            new() { Id = 6, Name = "Мастер по кондиционерам (+7 985 444-55-66)", Members = "Инженер ОВиК (ID: 14)", IsBusy = false },
            new() { Id = 7, Name = "Слесарь-сантехник (+7 910 555-66-77)", Members = "Слесарь (ID: 4)", IsBusy = false },
            new() { Id = 8, Name = "Электромонтажник (+7 977 666-77-88)", Members = "Электромонтажник (ID: 5)", IsBusy = true }
        };

        var allStages = new List<RepairStage>
        {
            new() { Id = 1, Property = allProperties[0], Brigade = allBrigades[2], PlanStart = new DateTime(2026, 11, 1), PlanEnd = new DateTime(2026, 11, 2), Status = StageStatus.Completed },
            new() { Id = 2, Property = allProperties[1], Brigade = allBrigades[0], PlanStart = new DateTime(2026, 11, 6), PlanEnd = new DateTime(2026, 11, 10), Status = StageStatus.Planned },
            new() { Id = 3, Property = allProperties[0], Brigade = allBrigades[1], PlanStart = new DateTime(2026, 11, 15), PlanEnd = new DateTime(2026, 11, 18), Status = StageStatus.InProgress },
            new() { Id = 4, Property = allProperties[2], Brigade = allBrigades[3], PlanStart = new DateTime(2026, 11, 2), PlanEnd = new DateTime(2026, 11, 5), Status = StageStatus.Completed },
            new() { Id = 5, Property = allProperties[3], Brigade = allBrigades[4], PlanStart = new DateTime(2026, 11, 3), PlanEnd = new DateTime(2026, 11, 7), Status = StageStatus.Completed },
            new() { Id = 6, Property = allProperties[4], Brigade = allBrigades[1], PlanStart = new DateTime(2026, 11, 4), PlanEnd = new DateTime(2026, 11, 12), Status = StageStatus.InProgress },
            new() { Id = 7, Property = allProperties[5], Brigade = allBrigades[0], PlanStart = new DateTime(2026, 11, 5), PlanEnd = new DateTime(2026, 11, 6), Status = StageStatus.Completed }
        };

        if (CurrentUser != null && CurrentUser.Role == UserRole.Client)
        {
            var clientMatches = allClients.Where(c => c.Email?.ToLower() == CurrentUser.Email.ToLower()).ToList();
            if (!clientMatches.Any())
            {
                clientMatches.Add(new Client
                {
                    Id = 999,
                    Name = CurrentUser.FullName,
                    Email = CurrentUser.Email,
                    Phone = "+7 (900) 000-00-00"
                });
            }

            Clients = new ObservableCollection<Client>(clientMatches);
            var clientIds = clientMatches.Select(c => c.Id).ToList();
            var propMatches = allProperties.Where(p => clientIds.Contains(p.ClientId)).ToList();
            Properties = new ObservableCollection<Property>(propMatches);

            var propIds = propMatches.Select(p => p.Id).ToList();
            RepairStages = new ObservableCollection<RepairStage>(allStages.Where(s => s.Property != null && propIds.Contains(s.Property.Id)));

            Brigades = new ObservableCollection<Brigade>();
            Materials = new ObservableCollection<Material>();
            WorkTypes = new ObservableCollection<WorkType>();
            Estimates = new ObservableCollection<Estimate>();
            ExtraWorks = new ObservableCollection<ExtraWork>();
            Payments = new ObservableCollection<Payment>();
            ActiveTab = "Properties";
        }
        else
        {
            Clients = new ObservableCollection<Client>(allClients);
            Properties = new ObservableCollection<Property>(allProperties);
            Brigades = new ObservableCollection<Brigade>(allBrigades);
            RepairStages = new ObservableCollection<RepairStage>(allStages);
            Materials = new ObservableCollection<Material>
            {
                new() { Id = 1, Name = "Цемент М500", Stock = 150, Price = 450 },
                new() { Id = 2, Name = "Штукатурка гипсовая", Stock = 80, Price = 600 },
                new() { Id = 3, Name = "Грунтовка глубокого проникновения", Stock = 45, Price = 350 },
                new() { Id = 4, Name = "Кабель ВВГнг 3х2.5 (м)", Stock = 300, Price = 120 },
                new() { Id = 5, Name = "Плитка керамогранит (кв.м)", Stock = 65, Price = 1800 }
            };
        }
    }

    [RelayCommand]
    private void DeleteItem()
    {
        if (SelectedItem == null) return;
        if (CurrentUser?.Role != UserRole.Director)
        {
            MessageBox.Show("У вас нет прав на удаление записей.", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (SelectedItem is Client c) Clients.Remove(c);
        else if (SelectedItem is Property p) Properties.Remove(p);
        else if (SelectedItem is Brigade b) Brigades.Remove(b);
        else if (SelectedItem is RepairStage s) RepairStages.Remove(s);
        else if (SelectedItem is Material m) Materials.Remove(m);
    }

    [RelayCommand]
    private void ExportToExcel()
    {
        try
        {
            switch (ActiveTab)
            {
                case "Clients": _excelService.Export(Clients, "ClientsReport.xlsx", "Клиенты"); break;
                case "Properties": _excelService.Export(Properties, "PropertiesReport.xlsx", "Объекты"); break;
                case "Brigades": _excelService.Export(Brigades, "BrigadesReport.xlsx", "Специалисты"); break;
                case "RepairStages": _excelService.Export(RepairStages, "StagesReport.xlsx", "Заказы"); break;
                default: _excelService.Export(Clients, "Report.xlsx", "Отчет"); break;
            }
            MessageBox.Show("Отчет успешно сохранен в папку с программой.", "HAMER", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка экспорта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}