using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using HamerApp.Data;
using HamerApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace HamerApp.ViewModels;

public partial class AuthViewModel : ObservableValidator
{
    [ObservableProperty]
    [NotifyDataErrorInfo]
    [Required(ErrorMessage = "Введите Email")]
    private string _email = string.Empty;

    [ObservableProperty]
    [NotifyDataErrorInfo]
    [Required(ErrorMessage = "Введите пароль")]
    private string _password = string.Empty;

    [ObservableProperty] private string _fullName = string.Empty;
    [ObservableProperty] private string _errorMessage = string.Empty;
    [ObservableProperty] private bool _isRegisterMode;

    public event Action<User>? OnLoginSuccess;
    public event Action? OnSwitchToRegister;
    public event Action? OnSwitchToLogin;

    [RelayCommand]
    private async Task Login()
    {
        ValidateAllProperties();
        if (HasErrors) return;

        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlite(App.ServiceProvider.GetRequiredService<IConfiguration>().GetConnectionString("DefaultConnection")).Options;
        using var db = new AppDbContext(options);

        var user = await db.Users.FirstOrDefaultAsync(u => u.Email == Email && u.Password == Password);
        if (user != null)
        {
            ErrorMessage = "";
            OnLoginSuccess?.Invoke(user);
        }
        else
        {
            ErrorMessage = "Неверный email или пароль";
        }
    }

    [RelayCommand]
    private async Task Register()
    {
        ValidateAllProperties();
        if (HasErrors) return;

        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseSqlite(App.ServiceProvider.GetRequiredService<IConfiguration>().GetConnectionString("DefaultConnection")).Options;
        using var db = new AppDbContext(options);

        var existingUser = await db.Users.FirstOrDefaultAsync(u => u.Email == Email);
        if (existingUser != null)
        {
            ErrorMessage = "Пользователь с таким email уже существует";
            return;
        }

        var newUser = new User
        {
            Email = Email,
            Password = Password,
            FullName = string.IsNullOrWhiteSpace(FullName) ? "Новый клиент" : FullName,
            Role = UserRole.Client
        };

        db.Users.Add(newUser);
        db.Clients.Add(new Client
        {
            Name = newUser.FullName,
            Phone = "+7 (900) 000-00-00",
            Email = newUser.Email
        });

        await db.SaveChangesAsync();

        ErrorMessage = "";
        OnLoginSuccess?.Invoke(newUser);
    }

    [RelayCommand]
    private void SwitchMode()
    {
        IsRegisterMode = !IsRegisterMode;
        if (IsRegisterMode)
            OnSwitchToRegister?.Invoke();
        else
            OnSwitchToLogin?.Invoke();
    }
}