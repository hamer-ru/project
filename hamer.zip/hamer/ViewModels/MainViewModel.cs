using System;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using HamerApp.Models;
using HamerApp.Views.Auth;
using HamerApp.Views.Public;
using HamerApp.Views.Workspace;
using Microsoft.Extensions.DependencyInjection;

namespace HamerApp.ViewModels;

public partial class MainViewModel : ObservableObject
{
    [ObservableProperty] private object _currentView;
    [ObservableProperty] private User? _currentUser;
    [ObservableProperty] private bool _isDarkTheme;
    [ObservableProperty] private string _activePage = "Home";
    
    private readonly HomeView _homeView;
    private readonly PricesView _pricesView;
    private readonly ContactsView _contactsView;
    private readonly VacanciesView _vacanciesView;
    private readonly ReviewsView _reviewsView;
    private readonly LoginView _loginView;
    private readonly RegisterView _registerView;
    private readonly AuthViewModel _authViewModel;
    private readonly WorkspaceView _workspaceView;
    private readonly WorkspaceViewModel _workspaceViewModel;
    private readonly PublicPagesViewModel _publicPages;

    public MainViewModel()
    {
        _publicPages = App.ServiceProvider.GetRequiredService<PublicPagesViewModel>();
        
        _homeView = new HomeView { DataContext = _publicPages };
        _pricesView = new PricesView { DataContext = _publicPages };
        _contactsView = new ContactsView { DataContext = _publicPages };
        _vacanciesView = new VacanciesView { DataContext = _publicPages };
        _reviewsView = new ReviewsView { DataContext = _publicPages };
        
        _authViewModel = App.ServiceProvider.GetRequiredService<AuthViewModel>();
        _loginView = new LoginView { DataContext = _authViewModel };
        _registerView = new RegisterView { DataContext = _authViewModel };
        
        _workspaceViewModel = App.ServiceProvider.GetRequiredService<WorkspaceViewModel>();
        _workspaceView = new WorkspaceView { DataContext = _workspaceViewModel };

        _authViewModel.OnLoginSuccess += (user) =>
        {
            CurrentUser = user;
            _workspaceViewModel.CurrentUser = user;
            CurrentView = _workspaceView;
        };

        _authViewModel.OnSwitchToRegister += () =>
        {
            CurrentView = _registerView;
        };

        _authViewModel.OnSwitchToLogin += () =>
        {
            CurrentView = _loginView;
        };

        _publicPages.NavigateToPricesRequested += NavigatePrices;
        _publicPages.NavigateToContactsRequested += NavigateContacts;

        CurrentView = _homeView;
    }

    [RelayCommand] private void NavigateHome() { CurrentView = _homeView; ActivePage = "Home"; }
    [RelayCommand] private void NavigatePrices() { CurrentView = _pricesView; ActivePage = "Prices"; }
    [RelayCommand] private void NavigateContacts() { CurrentView = _contactsView; ActivePage = "Contacts"; }
    [RelayCommand] private void NavigateVacancies() { CurrentView = _vacanciesView; ActivePage = "Vacancies"; }
    [RelayCommand] private void NavigateReviews() { CurrentView = _reviewsView; ActivePage = "Reviews"; }

    [RelayCommand]
    private void NavigateLogin()
    {
        if (CurrentUser != null)
        {
            CurrentView = _workspaceView;
        }
        else
        {
            CurrentView = _loginView;
        }
    }

    [RelayCommand]
    private void Logout()
    {
        CurrentUser = null;
        CurrentView = _homeView;
        ActivePage = "Home";
    }

    [RelayCommand]
    private void ToggleTheme()
    {
        IsDarkTheme = !IsDarkTheme;
        App.SwitchTheme(IsDarkTheme);
    }
}